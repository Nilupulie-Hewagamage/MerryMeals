package com.lithan.mow.model.constraint;

public enum ERole {
   ROLE_VOLUNTEER, 
   ROLE_CAREGIVER, 
   ROLE_MEMBER, 
   ROLE_RIDER, 
   ROLE_ADMIN, 
   ROLE_PARTNER
}
