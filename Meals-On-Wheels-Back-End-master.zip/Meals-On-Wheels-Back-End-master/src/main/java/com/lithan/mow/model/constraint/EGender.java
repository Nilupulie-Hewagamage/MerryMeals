package com.lithan.mow.model.constraint;

public enum EGender {
    MALE, FEMALE
}
