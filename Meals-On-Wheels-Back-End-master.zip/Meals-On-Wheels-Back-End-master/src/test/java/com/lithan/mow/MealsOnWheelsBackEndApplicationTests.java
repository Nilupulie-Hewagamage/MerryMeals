package com.lithan.mow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MealsOnWheelsBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
